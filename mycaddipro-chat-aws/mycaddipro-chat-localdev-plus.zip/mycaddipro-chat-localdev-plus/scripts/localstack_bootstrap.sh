#!/usr/bin/env bash
set -euo pipefail

# Bootstrap LocalStack resources for local dev.
: "${LOCALSTACK_URL:=http://localhost:4566}"
: "${QUEUE_NAME:=chat-messages}"
: "${S3_BUCKET:=mycaddipro-chat-uploads-dev}"

echo "Creating SQS queue: $QUEUE_NAME"
aws --endpoint-url="$LOCALSTACK_URL" sqs create-queue --queue-name "$QUEUE_NAME" >/dev/null

echo "Creating S3 bucket: s3://$S3_BUCKET"
aws --endpoint-url="$LOCALSTACK_URL" s3 mb "s3://$S3_BUCKET" || true

echo "Done. Exports to use:"
echo "  export SQS_URL=$LOCALSTACK_URL/000000000000/$QUEUE_NAME"
echo "  export LOCALSTACK_URL=$LOCALSTACK_URL"
echo "  export S3_BUCKET=$S3_BUCKET"
