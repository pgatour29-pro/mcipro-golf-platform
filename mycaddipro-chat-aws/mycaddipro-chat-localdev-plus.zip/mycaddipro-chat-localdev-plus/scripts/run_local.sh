#!/usr/bin/env bash
set -euo pipefail

# Bring up local infra
docker compose -f infra/docker-compose.yml up -d

# Bootstrap LocalStack
scripts/localstack_bootstrap.sh

# Apply DB schema
psql "postgres://chatuser:chatpass@localhost:5432/chatdb" -f db/schema.sql

# Start services in background terminals (prints commands to run)
cat <<'CMDS'
# Terminal A
cd backend/chat-api
npm i
DEV_BYPASS_AUTH=1 PG_URL=postgres://chatuser:chatpass@localhost:5432/chatdb \
SQS_URL=http://localhost:4566/000000000000/chat-messages \
LOCALSTACK_URL=http://localhost:4566 \
REDIS_URL=redis://localhost:6379 \
npm run start:dev

# Terminal B
cd backend/chat-realtime
npm i
REDIS_URL=redis://localhost:6379 npm run start

# Terminal C
cd backend/fanout-worker
npm i
LOCALSTACK_URL=http://localhost:4566 \
SQS_URL=http://localhost:4566/000000000000/chat-messages \
REDIS_URL=redis://localhost:6379 \
npm run start

# Terminal D (frontend)
cd frontend
npm i
NEXT_PUBLIC_API=http://localhost:4000 \
NEXT_PUBLIC_RT=ws://localhost:4100/v1/realtime \
npm run dev
CMDS
