# Deployment Checklist (fill-in)

## 1) AWS Account Info
- [ ] **VPC ID:** vpc-__________
- [ ] **Private Subnet IDs (RDS/Redis/ECS):** ["subnet-____","subnet-____"]
- [ ] **Public Subnet IDs (ALB):** ["subnet-____","subnet-____"]
- [ ] **Preferred Region:** ap-southeast-1 (or: __________)

## 2) LINE Login Credentials
- [ ] **LINE Channel ID:** __________
- [ ] **LINE Channel Secret:** __________
- [ ] **Redirect URI:** https://chat.mycaddipro.com/auth/callback (or: __________)

## 3) Domain Setup
- [ ] **Cloudflare access** to manage DNS for **chat.mycaddipro.com**
- [ ] TLS option:
  - [ ] **AWS ACM (recommended)** — set Route53 zone + domain in tfvars (automatic), or use external DNS variant and add the printed CNAMEs.
  - [ ] **Cloudflare cert** terminating at Cloudflare → ALB HTTP (not recommended for WS), or Cloudflare → ALB HTTPS with ACM.

## 4) Secrets Handling
- Store sensitive values (DB password, LINE secret) in:
  - AWS Secrets Manager or SSM Parameter Store, and **inject into ECS tasks** via task definitions (preferred), or
  - GitHub Actions OpenID → temporary creds to fetch secrets at deploy.
- Never commit real secrets to git. Use `.env.production.example` as a guide.

## 5) Runbooks
- **Local test:** `docker compose -f docker-compose.dev.yml up --build -d` → `bash scripts/localstack_bootstrap.sh` → open http://localhost:3000
- **ECR push:** use `.github/workflows/ecr_build.yml` or `docker build && docker push` manually.
- **Terraform:** `terraform init && terraform apply -var-file=infra/prod.tfvars`
