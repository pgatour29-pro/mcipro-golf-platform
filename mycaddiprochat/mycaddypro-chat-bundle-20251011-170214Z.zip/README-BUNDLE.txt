MyCaddyPro Chat Bundle — 20251011-170214Z

Contents:
- /chat: client code
- /sql: schema & RLS
- /edge: edge functions
- /docs: guides
