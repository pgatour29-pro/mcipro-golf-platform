# Resilient Chat @ chat.mycaddipro.com — Starter Kit

This repo is a pragmatic starting point to run chat as an **independent** service that
keeps working during platform incidents.

## What’s inside
- **docs/** — Architecture, migration plan, and API reference
- **backend/chat-api/** — NestJS HTTP API (`POST /v1/messages`, `GET /v1/messages`), SQS producer, Postgres storage
- **backend/chat-realtime/** — Node WebSocket server with simple fanout and SSE fallback
- **frontend/** — Next.js app with IndexedDB outbox, retries, and degraded-mode UI
- **db/** — Postgres schema (append-only, idempotent)
- **infra/** — Terraform stubs for AWS (Aurora Postgres, SQS, ECS), plus local dev via docker-compose
- **scripts/** — cURL examples and chaos drill checklist

## Quickstart (local dev)
```bash
# 1) Start Postgres + LocalStack (SQS) + Redis
docker compose up -d

# 2) Start services
cd backend/chat-api && npm i && npm run start:dev
cd ../chat-realtime && npm i && npm run start
cd ../../frontend && npm i && npm run dev

# 3) Open the app
open http://localhost:3000
```

## Non-goals
- This is intentionally minimal. Add your auth integration (OIDC/JWT), Cloud infra, and production hardening.
