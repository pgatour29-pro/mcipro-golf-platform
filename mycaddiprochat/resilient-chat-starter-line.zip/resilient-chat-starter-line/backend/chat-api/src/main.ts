import 'reflect-metadata';
import express from 'express';
import { oidcMiddleware } from './auth/oidc';
import { randomUUID } from 'crypto';
import { Pool } from 'pg';
import { SQS } from 'aws-sdk';
import { z } from 'zod';

const app = express();
app.use(express.json({ limit: '256kb' }));

// --- config (env) ---
const PORT = process.env.PORT || 4000;
const PG_URL = process.env.PG_URL || 'postgres://chatuser:chatpass@localhost:5432/chatdb';
const SQS_URL = process.env.SQS_URL || 'http://localhost:4566/000000000000/chat-messages';

const pool = new Pool({ connectionString: PG_URL });
const sqs = new SQS({ region: 'ap-southeast-1', endpoint: SQS_URL.includes('localhost') ? 'http://localhost:4566' : undefined });

// simple health
app.get('/healthz', (_req, res) => res.json({ ok: true }));

// zod schema
const SendSchema = z.object({
  conversation_id: z.string().uuid(),
  message_id: z.string().uuid(),
  sender_id: z.string().uuid(),
  body: z.string().min(1).max(4000),
  attachments: z.array(z.any()).optional()
});

app.post('/v1/messages', oidcMiddleware(), async (req, res) => {
  const parsed = SendSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { conversation_id, message_id, sender_id, body, attachments } = parsed.data;
  try {
    // idempotent insert
    await pool.query(
      'insert into messages (conversation_id, message_id, sender_id, body, attachments) values ($1,$2,$3,$4,$5) on conflict (conversation_id, message_id) do nothing',
      [conversation_id, message_id, sender_id, body, JSON.stringify(attachments || [])]
    );
    // enqueue for fanout
    await sqs.sendMessage({ QueueUrl: SQS_URL, MessageBody: JSON.stringify(parsed.data), MessageGroupId: conversation_id }).promise().catch(() => {});
    return res.status(202).json({ status: 'accepted' });
  } catch (e:any) {
    return res.status(500).json({ error: e.message });
  }
});

app.get('/v1/messages', oidcMiddleware(), async (req, res) => {
  const { conversation_id, after_cursor } = req.query as any;
  if (!conversation_id) return res.status(400).json({ error: 'conversation_id required' });
  try {
    const result = await pool.query(
      'select conversation_id, message_id, sender_id, body, attachments, created_at from messages where conversation_id=$1 and created_at > coalesce($2::timestamptz, to_timestamp(0)) order by created_at asc limit 100',
      [conversation_id, after_cursor || null]
    );
    const next = result.rows.length ? result.rows[result.rows.length - 1].created_at : after_cursor;
    return res.json({ messages: result.rows, next_cursor: next });
  } catch (e:any) {
    return res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => console.log(`chat-api listening on :${PORT}`));
