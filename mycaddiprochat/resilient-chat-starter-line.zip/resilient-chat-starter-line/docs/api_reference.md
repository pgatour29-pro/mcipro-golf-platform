# API Reference (minimal)

## POST /v1/messages
Request:
```json
{ "conversation_id": "uuid", "message_id": "uuid", "sender_id": "uuid", "body": "text", "attachments": [] }
```
Response: `202 Accepted`

## GET /v1/messages?conversation_id=...&after_cursor=...
Response:
```json
{ "messages": [ ... ], "next_cursor": "..." }
```

## WS /v1/realtime
Client sends subscribe payload:
```json
{ "type": "subscribe", "conversation_id": "uuid", "last_cursor": null }
```
Server pushes messages:
```json
{ "type": "message", "payload": { ... } }
```
