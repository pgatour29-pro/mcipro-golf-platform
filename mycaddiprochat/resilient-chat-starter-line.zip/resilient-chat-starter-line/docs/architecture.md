# North-Star Architecture (Option D)

```
[Browser @ chat.mycaddipro.com]
   |  WS / HTTP (JWT)
   v
[Edge/CDN/WAF]  --->  [chat-realtime]  <---subscribe--  [Queue: SQS/Kafka]
   |                        |  publishes                           ^
   |  HTTP                  v                                     |
   ---> [chat-api] -----> [Postgres (chat-db)]  <---async--- [workers: enrich, receipts, search]
```

**Hot path** touches only: `chat-api` → `chat-db` → queue → `chat-realtime`.
No synchronous calls to other platform services on send/receive.
