# LINE Login (OIDC) Integration — Quick Steps

1. Create a LINE Login channel and note **Channel ID** and **Channel secret**.
2. Set callback URL to `https://chat.mycaddipro.com/auth/callback`.
3. Fill `.env`:
   - `OIDC_ISSUER=https://access.line.me`
   - `OIDC_CLIENT_ID=<Channel ID>`
   - `OIDC_CLIENT_SECRET=<Channel secret>`
   - `OIDC_REDIRECT_URI=https://chat.mycaddipro.com/auth/callback`
4. Frontend: the `/auth` page sends users to LINE authorize.
5. Backend: implement `/oauth/exchange` to trade `code` for tokens (use LINE token endpoint) and mint a short-lived **chat JWT** for your API.
6. All chat endpoints require `Authorization: Bearer <chat JWT>` (see `oidc.ts`).

> For local dev, you can skip full OIDC and run endpoints without the middleware.
