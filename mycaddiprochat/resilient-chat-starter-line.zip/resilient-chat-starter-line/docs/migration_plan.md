# Migration Plan (Phased)

**Phase 0 – PoC**
- Spin up chat-api + chat-realtime with their own Postgres and queue
- Wire `POST /v1/messages` and WebSocket fanout

**Phase 1 – Auth + Client Queue**
- JWT exchange + JWKS cache
- Client outbox (IndexedDB), idempotency keys, backoff

**Phase 2 – Partial Cut**
- Route new 1:1 conversations to new stack
- Remove sync calls to platform services on send path

**Phase 3 – Harden**
- Chaos drills (take platform APIs down)
- Dashboards, alarms, on-call runbooks

**Phase 4 – Full Cutover**
- 10% → 50% → 100% traffic shift, dark read path for a week
