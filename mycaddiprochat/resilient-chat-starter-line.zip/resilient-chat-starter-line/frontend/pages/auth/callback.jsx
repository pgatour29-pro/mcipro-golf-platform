import { useRouter } from 'next/router';
import { useEffect } from 'react';

export default function Callback() {
  const router = useRouter();
  useEffect(() => {
    // In production you would POST the code to chat-api to exchange for a chat JWT
    // then store it and use it in Authorization headers.
    const { code, state } = router.query;
    console.log('Received code', code, 'state', state);
  }, [router.query]);
  return <main style={{ maxWidth: 600, margin: '40px auto' }}><h1>Auth Callback</h1><p>Code received. Finish the exchange on the backend.</p></main>;
}
