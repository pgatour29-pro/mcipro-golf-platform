import { v4 as uuid } from 'uuid';
import { set, get } from 'idb-keyval';
import { useEffect, useRef, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API || 'http://localhost:4000';
const RT = process.env.NEXT_PUBLIC_RT || 'ws://localhost:4100/v1/realtime';

export default function Home() {
  const [cid, setCid] = useState('00000000-0000-0000-0000-000000000001');
  const [uid, setUid] = useState('00000000-0000-0000-0000-000000000002');
  const [body, setBody] = useState('');
  const [log, setLog] = useState([]);
  const wsRef = useRef(null);

  useEffect(() => {
    const ws = new WebSocket(RT);
    wsRef.current = ws;
    ws.onopen = () => ws.send(JSON.stringify({ type: 'subscribe', conversation_id: cid }));
    ws.onmessage = (e) => {
      const msg = JSON.parse(e.data);
      if (msg.type === 'message') setLog((l) => [...l, msg.payload]);
    };
    ws.onclose = () => console.log('ws closed');
    return () => ws.close();
  }, [cid]);

  async function send() {
    const mid = uuid();
    const payload = { conversation_id: cid, message_id: mid, sender_id: uid, body };
    await set(`outbox:${mid}`, payload);
    try {
      const r = await fetch(`${API}/v1/messages`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      if (!r.ok) throw new Error('send failed');
      setBody('');
    } catch (e) {
      console.warn('queued (offline)', e);
      // naive retry
      setTimeout(send, 3000);
    }
  }

  return (
    <main style={{ maxWidth: 600, margin: '40px auto', fontFamily: 'Inter, system-ui', padding: 16 }}>
      <h1>Resilient Chat (Starter)</h1>
      <div style={{ marginBottom: 8 }}>
        <label>Conversation ID</label>
        <input value={cid} onChange={e => setCid(e.target.value)} style={{ width: '100%' }} />
      </div>
      <div style={{ marginBottom: 8 }}>
        <label>Your User ID</label>
        <input value={uid} onChange={e => setUid(e.target.value)} style={{ width: '100%' }} />
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <input value={body} onChange={e => setBody(e.target.value)} placeholder="Type a message" style={{ flex: 1 }} />
        <button onClick={send}>Send</button>
      </div>
      <hr />
      <ul>
        {log.map((m, i) => (<li key={i}><code>{m.sender_id}</code>: {m.body}</li>))}
      </ul>
    </main>
  );
}
