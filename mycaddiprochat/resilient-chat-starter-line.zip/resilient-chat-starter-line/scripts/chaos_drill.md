# Chaos Drill (local)
- Stop the API that simulates your main platform (if any). Keep chat-api and chat-realtime running.
- Try sending messages: they should be accepted (202), stored, and fanned out.
- Stop Redis or the fanout worker: messages should still be stored; realtime delivery will catch up on restart.
- Stop Postgres: sends should fail and queue in the client (IndexedDB). UI should show queued/degraded.
